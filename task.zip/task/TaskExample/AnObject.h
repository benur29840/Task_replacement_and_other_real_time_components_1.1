class AnObject
{
	int id;
public:
	AnObject(int Id){id = Id;};
	
	~AnObject(){};
	
	int getId(){return id;};

};