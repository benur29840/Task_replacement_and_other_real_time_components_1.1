#include "Task.h"

#include "AnObject.h"

#ifdef HAVE_STD
#include <iostream>
using namespace std;
#else
#include <iostream.h>
#endif

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif

static Mutex OnlyOneCout;

class ATaskClass : public AnObject, public task
{
public:
	ATaskClass(int Id) : AnObject(Id), task()
	{
		cout << "constructor ATaskClass : " << getId() << endl;
#ifdef _SYSTEM_V
		Loop();
#else
		buildingMutex->_unlock();
#endif
	};

	~ATaskClass()
	{
	};

	void Loop()
	{
		while(rdstate() == RUNNING)
		{
			OnlyOneCout._lock();
			cout << "I am the ATaskClass : " << getId() << endl;
			OnlyOneCout._unlock();
#ifdef _WIN32
			Sleep (1000); //1s
#else
			usleep(1000000); //1s
#endif
		}
#ifndef _SYSTEMV
		state = TERMINATED;
		cout << "state : TERMINATED" << endl;
#endif
	};
};
