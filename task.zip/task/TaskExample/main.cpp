#include "ATaskClass.h"

#include <string.h>

int main (int argc, char **argv)
{
	ATaskClass* task1 = new ATaskClass(1);
	ATaskClass* task2 = new ATaskClass(2);
	ATaskClass* task3 = new ATaskClass(3);
	ATaskClass* task4 = new ATaskClass(4);

	char line[256];
	while(true)
	{
		cin >> line;
		if(strcmp(line, "exit") == 0)
			break;
	}

	task1->resultis(0);
	task2->resultis(0);
	task3->resultis(0);
	task4->resultis(0);
	delete task4;
	delete task3;
	delete task2;
	delete task1;

	return 0;
}
