/* -*- Mode: C++; -*-
 *                            
 * ThreadClass.cpp              Created on: 2016/11/09
 *                            Author    : Rock Benoit
 *
 *    Copyright (C) 2016 Rock's Architecture
 *
 * 
 *    The Task library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  
 *    02111-1307, USA
 *
 *
 * Description:
 *
 *
 *      ThreadClass.cpp
 *
 *    Uses different libraries 
 *    Expressive preprocessor flags to use one of these libraries are :
 *    _BOOST,  _GNU_PTH, _SOLARIS, _ACE, _OMNIORB, _PURE_WIN32, default : POSIX pthread
 *
 */

#ifndef _SYSTEMV

#include "ThreadClass.h"

#ifndef _BOOST
#ifdef _OMNIORB
void ThreadClass::run(void* p)
{
	_theTaskId = id ();
	buildingMutex->_lock ();
	delete buildingMutex;
	buildingMutex = NULL;
	Loop ();
}
#else
unsigned long ThreadFunction (void *lpdwParam)
{
	((ThreadClass*)lpdwParam)->buildingMutex->_lock (); // waiting task is build and having good Loop(), not a pure virtual one
	delete ((ThreadClass*)lpdwParam)->buildingMutex;
	((ThreadClass*)lpdwParam)->buildingMutex = NULL;
	((ThreadClass*)lpdwParam)->Loop ();
	return 0;
}

#ifndef _PURE_WIN32
void * threadFunction (void *lpdwParam)
{
	ThreadFunction (lpdwParam);
	return NULL;
}
#endif
#endif
#else
void run(void* lpdwParam)
{
	((ThreadClass*)lpdwParam)->_theTaskId = boost::this_thread::get_id ();
	((ThreadClass*)lpdwParam)->buildingMutex->_lock ();
	delete ((ThreadClass*)lpdwParam)->buildingMutex;
	((ThreadClass*)lpdwParam)->buildingMutex = NULL;
	((ThreadClass*)lpdwParam)->Loop ();
}
#endif

#ifdef _OMNIORB
ThreadClass::ThreadClass () : omni_thread ()
#else
ThreadClass::ThreadClass ()
#endif
{
	buildingMutex = new Mutex ();
	buildingMutex->_lock ();
#ifdef _BOOST
	boost::thread (run, this);
#else
#ifdef _GNU_PTH
	pthread_create (&_theTaskId, NULL,threadFunction, this);
#else
#ifdef _SOLARIS
	thr_create (0, 0, threadFunction, this, THR_BOUND, &_theTaskId);
#else
#ifdef _ACE
	ACE_Thread::spawn ((ACE_THR_FUNC)threadFunction, this, THR_DETACHED, &_theTaskId);
#else
#ifdef _OMNIORB
	start ();
#else
#ifdef _PURE_WIN32
	objectHandle = CreateThread (NULL, 0, (LPTHREAD_START_ROUTINE) ThreadFunction, (LPDWORD) this, 0, &_theTaskId);
#else
	pthread_create (&_theTaskId, NULL, threadFunction, this);
#endif
#endif
#endif
#endif
#endif
#endif
}

ThreadClass::~ThreadClass()
{
#ifdef _PURE_WIN32
	if(objectHandle != NULL)
	{
		CloseHandle (objectHandle);
		objectHandle = NULL;
	}
#endif
}

#endif //_SYSTEMV
