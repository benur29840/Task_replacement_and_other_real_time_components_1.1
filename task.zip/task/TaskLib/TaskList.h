/* -*- Mode: C++; -*-
 *                            
 * TaskList.h                 Created on: 2016/11/09
 *                            Author    : Rock Benoit
 *
 *    Copyright (C) 2016 Rock's Architecture
 *
 * 
 *    The Task library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  
 *    02111-1307, USA
 *
 *
 * Description:
 *
 *
 *      TaskList.h
 *
 */

#ifndef _SYSTEMV

#ifdef DEBUG
#pragma message ("#INCLUDING " __FILE__)
#endif

#ifndef _TASKLIST_
#define _TASKLIST_

#include "Task.h"

class TaskList
{
public :
	int	length;

	TaskList();
	~TaskList();

	void	Add(task* theTask);
	void	Remove(task* theTask);
#ifdef _BOOST
	task* TaskList::Find(boost::thread::id* taskId);
#else
#ifdef _GNU_PTH
	task*	Find(pthread_t* taskId);
#else
#ifdef _SOLARIS
	task*	Find(thread_t* taskId);
#else
#ifdef _TAO
	task*	Find(ACE_thread_t* taskId);
#else
#ifdef _OMNIORB
	task*	Find(int* taskId);
#else
#ifdef _PURE_WIN32
	task*	Find(DWORD* taskId);
#else
	task*	Find(pthread_t* taskId);
#endif
#endif
#endif
#endif
#endif
#endif
	bool	AreOthersTasksTerminated(ThreadClass* taskHandle);
	task*	last();

private :
	ListOfPointers<task>	TaskPtrList;
};

#endif
#endif //_SYSTEMV
