/* -*- Mode: C++; -*-
 *                            
 * Mutex.h                    Created on: 2016/11/09
 *                            Author    : Rock Benoit
 *
 *    Copyright (C) 2016 Rock's Architecture
 *
 * 
 *    The Task library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  
 *    02111-1307, USA
 *
 *
 * Description:
 *
 *
 *      Mutex.h
 *
 *    POSIX mutex class
 *    Acts like a semaphore(1)
 *    Uses different libraries 
 *    Expressive preprocessor flags to use one of these libraries are :
 *    _BOOST, _IPC, _GNU_PTH, _SOLARIS, _ACE, _OMNIORB, _PURE_WIN32 _PTHREAD or default (No flag)
 *
 *    Defines a waitForMultipleMutexes function acting like the Windows's : 
 *      WaitForMultipleObjects(DWORD nCount, const HANDLE *lpHandles, bool bWaitAll, DWORD dwMilliseconds)
 *
 *    Defines the Windows's DWORD GetTickCount(void)
 *
 */

#ifdef DEBUG
#pragma message ("#INCLUDING " __FILE__)
#endif

#ifndef _MUTEX_H__
#define _MUTEX_H__

//see https://sourceforge.net/p/predef/wiki/Compilers/ and add your compiler then mail me to help community please
#if defined (__GNUG__) || defined (_MSC_VER) || defined (__BORLANDC__)
#ifndef HAVE_STD
#define HAVE_STD
#endif
#endif

#define HAVE_MUTEX

#include <errno.h>

#ifdef _BOOST //C++ library Boost
	#include <windows.h>
	#ifdef _MSC_VER
	   #pragma push_macro("uint64_t")
		#undef uint64_t
	   #pragma push_macro("int64_t")
		#undef int64_t
	#endif
	   // entire normal contents of the header here, including boost #include
		#include <boost/thread/condition_variable.hpp>
		#include <boost/thread/mutex.hpp>
	#ifdef _MSC_VER
	   #pragma pop_macro("int64_t")
	   #pragma pop_macro("uint64_t")
	#endif
#else
	#ifdef _IPC //http://www.blaess.fr/christophe/2011/10/09/efficacite-des-ipc-semaphore-et-memoire-partagee/
		#include <sched.h>
		#include <semaphore.h>
	#else
		#ifdef _GNU_PTH
			#include <pthread.h>
			#include <pth.h>
		#else
			#ifdef _SOLARIS
				#include <thread.h>
			#else
				#ifdef _ACE
					#include <ace/Thread_Mutex.h>
				#else
					#ifdef _OMNIORB
						#include <omnithread.h>
					#else
						#ifdef _PURE_WIN32 //because pthread exists for windows too
							#include <windows.h>
						#else
							#ifdef _PTHREAD
								#include <pthread.h>
							#else
								#define _DEFAULT
								#ifdef _WIN32
									#include <windows.h>
								#else
									#include <unistd.h>
								#endif
							#endif
						#endif
					#endif
				#endif
			#endif
		#endif
	#endif
#endif

#ifndef _PURE_WIN32
#include <time.h>       /* clock_t, clock() */
#endif

#ifdef _ACE
class Mutex : public ACE_Thread_Mutex
#else
#ifdef _OMNIORB
class Mutex : public omni_semaphore
#else
class Mutex
#endif
#endif
{
public:

	Mutex();
#if !defined (_OMNIORB) && !defined (_ACE)
	~Mutex();
#endif

	bool locked;

	int _lock ();

	int _trylock (); //return EBUSY if locked

	int _unlock ();

#ifndef _PURE_WIN32 //see waitForMultipleMutexes
private:
#endif

#ifdef _BOOST
	boost::mutex mutex_;
	boost::condition_variable cv;
    int count;
#else
#ifdef _IPC
	sem_t* mutex_;
#else
#ifdef _GNU_PTH
	pth_mutex_t mutex_;
#else
#ifdef _SOLARIS
	mutex_t mutex_;
#else
#ifdef _ACE
#else
#ifdef _OMNIORB
#else
#ifdef _PURE_WIN32
	HANDLE mutex_;
#else
#ifdef _PTHREAD
	pthread_mutex_t mutex_;
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
};

#ifndef _WIN32
#define INFINITE 0
#define WAIT_TIMEOUT 0x00000102L
#define WAIT_OBJECT_0 0

unsigned long GetTickCount();
#endif

//DWORD WaitForMultipleObjectsEx(DWORD  nCount, HANDLE **array, bool bWaitAll, DWORD          dwMilliseconds)
  size_t waitForMultipleMutexes (size_t nCount, Mutex  **array, bool bWaitAll, unsigned long  dwMilliseconds);

#endif
