/* -*- Mode: C++; -*-
 *                            
 * task.cpp                   Created on: 2016/11/09
 *                            Author    : Rock Benoit
 *
 *    Copyright (C) 2016 Rock's Architecture
 *
 * 
 *    The Task library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  
 *    02111-1307, USA
 *
 *
 * Description:
 *
 *
 *      task.cpp
 *
 *    SYSTEM V replacement
 *    To use with Mutex, ThreadClass and ListOfPointers
 *
 *
 */

#ifndef _SYSTEMV

#include "Task.h"

#include "TaskList.h"

#include <string.h>
#include <climits>
#ifndef _WIN32
#include <unistd.h>
#endif

TaskList    TheTaskList;       //used in this_task()
static bool firstTask = true;  //allow to construct the Main Task
long nbThreads = 0;

//Class object

object::object()
{
	someoneWaitingFor = false;
	objectPendingMutex = new Mutex ();
}

object::~object()
{
	objectPendingMutex->_unlock ();
	delete objectPendingMutex;
	objectPendingMutex = NULL;
}


void object::alert ()
{
	return;
}

task *object::this_task ()
{
	task *ret;
#ifdef _BOOST
	boost::thread::id id = boost::this_thread::get_id();
#else
#ifdef _GNU_PTH
	pthread_t id = pthread_self ();
#else
#ifdef _SOLARIS
	thread_t id = thr_self();
#else
#ifdef _ACE
	ACE_thread_t id = ACE_Thread::self();
#else
#ifdef _OMNIORB
	int id = omni_thread::self()->id();
#else
#ifdef _PURE_WIN32
	DWORD id = GetCurrentThreadId ();
#else
	pthread_t id = pthread_self ();
#endif
#endif
#endif
#endif
#endif
#endif
	ret = TheTaskList.Find (&id);

	return ret;
}

// Class task
task::task(char *name, modetype mode, int size) : object(), ThreadClass ()
{
	nbThreads++;
	if (firstTask)
	{
		firstTask = false;
		task *mainTask = new task ("Main Task");
		mainTask->state = TERMINATED;
#ifdef _BOOST
		mainTask->_theTaskId = boost::this_thread::get_id();
#else
#ifdef _GNU_PTH
		mainTask->_theTaskId = pthread_self ();
#else
#ifdef _SOLARIS
		mainTask->_theTaskId = thr_self()
#else
#ifdef _ACE
		mainTask->_theTaskId = ACE_Thread::self();
#else
#ifdef _OMNIORB
		mainTask->_theTaskId = id();
#else
#ifdef _PURE_WIN32
		mainTask->objectHandle = GetCurrentThread ();
		mainTask->_theTaskId = GetCurrentThreadId ();
#else
		mainTask->_theTaskId = pthread_self ();
#endif
#endif
#endif
#endif
#endif
#endif
	}

	int len = 0;
	if (name != NULL && (strlen (name) > 0))
	{
		len = (int) strlen (name);
		t_name = new char[len + 1];
#ifdef _MSC_VER 
		strncpy_s(t_name, len+1, name, len);
#else
		strncpy (t_name, name, len);
#endif
	}
	else
	{
		t_name = new char[1];
	}
	t_name[len] = '\0';

	state = RUNNING;
	Val = INT_MIN;
	TheTaskList.Add (this);
	objectPendingMutex->_lock ();
}

task::~task()
{
	state = KILLED;
	nbThreads--;

	if (t_name)
	{
		delete [] t_name;
		t_name = NULL;
	}
	TheTaskList.Remove (this);
}

void task::resultis (int val)
{
	Val = val;
	cancel ();
}

int  task::result ()
{
	return Val;
}

void  task::cancel ()
{
	state = KILLED;
	while(state != TERMINATED)
#ifdef _WIN32
		Sleep (1);
#else
		usleep (1);
#endif
}

int task::waitvec (object **taskTab)
{
	size_t i, ret, size = 0;
	Mutex **tab;
	object **pt = taskTab;

	while (*pt != NULL)
	{
		size++;
		pt++;
	}

	pt = taskTab;
	tab = new Mutex *[size];

	for (i = 0; i < size; i++)
	{
		tab[i] = (*taskTab)->objectPendingMutex;
		(*taskTab)->someoneWaitingFor = true;
		taskTab++;
	}
	state = IDLE;
	ret = waitForMultipleMutexes (size, tab, false, INFINITE);
	state = RUNNING;
	tab[ret]->_unlock ();

	delete[] tab;

	taskTab = pt;
	for (i = 0; i < size; i++)
	{
		(*taskTab)->someoneWaitingFor = false;
		taskTab++;
	}

	return (int) ret;
}

statetype task::rdstate ()
{
	return state;
}

//Class qhead
qhead::qhead(qmodetype mod, int siz)
{
	q = new ListOfPointers<object>((size_t) siz);
	mode = mod;
	theTail = new qtail (q, mod, this);

	emptyMutex = new Mutex ();
	emptyMutex->_lock ();
	objectPendingMutex->_lock ();
	isLocked = false;
}

qhead::~qhead()
{
	if (isLocked)
	{
		theTail->put (NULL);
		while (isLocked)
		{
		}
	}
	if (q != NULL)
	{
		delete q;
		q = NULL;
	}
	if (theTail != NULL)
	{
		delete theTail;
		theTail = NULL;
	}
	emptyMutex->_unlock ();
	delete emptyMutex;
	emptyMutex = NULL;
}

int qhead::pending ()
{
	bool ret = false;

	if ((q != NULL) && (q->length () == 0))
		ret = true;

	return ret;
}

object *qhead::get ()
{
	object *result = NULL;

	isLocked = true;
	blockHead ();
	if (q)
		result = q->get ();
	else
		result = NULL;
	if (theTail != NULL)
		theTail->freeTail ();

	if (!pending ())
		freeHead ();

	isLocked = false;
	return result;
}


qtail *qhead::tail ()
{
	return theTail;
}

void qhead::freeHead ()
{
	emptyMutex->_unlock ();
	objectPendingMutex->_unlock ();
}

void qhead::blockHead ()
{
	someoneWaitingFor = true;
	emptyMutex->_lock ();
	objectPendingMutex->_lock ();
	someoneWaitingFor = false;
}

int qhead::rdcount ()
{
	if (q != NULL)
		return q->length ();
	else
		return 0;
}

//Class qtail
qtail::qtail(qmodetype mod, int siz)
{
	qMustBeDestroyed = true;
	q = new ListOfPointers<object>(siz);
	mode = mod;
	fullMutex = new Mutex ();
	theHead = NULL;
}

qtail::~qtail()
{
	if (qMustBeDestroyed)
	{
		if (q != NULL)
		{
			delete q;
			q = NULL;
		}
		if (theHead != NULL)
		{
			delete theHead;
			theHead = NULL;
		}
	}
	fullMutex->_unlock ();
	delete fullMutex;
	fullMutex = NULL;
}

qhead *qtail::head ()
{
	return theHead;
}

qtail::qtail(ListOfPointers<object> *queue, qmodetype mod, qhead *qh)
{
	qMustBeDestroyed = false;
	q = queue;
	mode = mod;
	theHead = qh;
	fullMutex = new Mutex ();
	objectPendingMutex = new Mutex ();
}

int qtail::pending ()
{
	if (q)
	{
		if (q->IsFull ())
			return true;
		else
			return false;
	}
	else
	{
		return true;
	}
}

int qtail::put (object *p_obj)
{
	blockTail ();
	q->put (p_obj);
	theHead->freeHead ();
	if (!pending ())
		freeTail ();
	return 1;
}

void qtail::freeTail ()
{
	fullMutex->_unlock ();
	objectPendingMutex->_unlock ();
}

void qtail::blockTail ()
{
	fullMutex->_lock ();
	objectPendingMutex->_lock ();
}


task *thistaskBuild ()
{
	task *ret;

	ret = TheTaskList.last ();

	return ret;
}

#endif //_SYSTEMV
