/* -*- Mode: C++; -*-
 *                            
 * Mutex.cpp                  Created on: 2016/11/09
 *                            Author    : Rock Benoit
 *
 *    Copyright (C) 2016 Rock's Architecture
 *
 * 
 *    The Task library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  
 *    02111-1307, USA
 *
 *
 * Description:
 *
 *
 *      Mutex.cpp
 *
 *    POSIX mutex class
 *    Acts like a semaphore(1)
 *    Uses different libraries 
 *    Expressive preprocessor flags to use one of these libraries are :
 *    _BOOST, _IPC, _GNU_PTH, _SOLARIS, _TAO, _OMNIORB, _PURE_WIN32, default : POSIX pthread
 *
 *    Defines a waitForMultipleMutexes function acting like the Windows's : 
 *      WaitForMultipleObjectsEx(DWORD nCount, const HANDLE *lpHandles, bool bWaitAll, DWORD dwMilliseconds, true)
 *
 *    Defines the Windows's DWORD GetTickCount(void)
 *
 */

#include "Mutex.h"

#ifndef _PURE_WIN32
#include <time.h>
#endif
#include <errno.h>

#ifdef _IPC
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
static long Number = 0;
#endif

#ifdef _TAO
	Mutex::Mutex() : ACE_Thread_Mutex()
#else
#ifdef _OMNIORB
	Mutex::Mutex() : omni_semaphore (1)
#else
	Mutex::Mutex ()
#endif
#endif
	{
		locked = false;
#ifdef _BOOST
		count = 1;
#else
#ifdef _IPC
		char* Name;
		sprintf(Name, "/mutex_%d_%d", getppid(), Number);
		//open an exchange file
		mutex_ = sem_open(Name, O_CREAT | O_RDWR, 0600, 0);
		if (mutex_ == SEM_FAILED)
		{
			perror(Name);
			exit(EXIT_FAILURE);
		}
		sem_unlink(Name);
#else
#ifdef _GNU_PTH
		mutex_ = PTHREAD_MUTEX_INITIALIZER;
		pth_mutex_init (&mutex_);
#else
#ifdef _SOLARIS
		mutex_init (&mutex_, USYNC_THREAD, NULL);
#else
#ifdef _TAO
#else
#ifdef _OMNIORB
#else
#ifdef _PURE_WIN32
		mutex_ = CreateSemaphore (NULL, 1, 1, NULL);
#else
#if __cplusplus > 199711L //since C++11
		mutex_ = PTHREAD_MUTEX_INITIALIZER;
#endif
		pthread_mutex_init (&mutex_, 0);
#endif
#endif
#endif
#endif
#endif
#endif
#endif
	}

#if !defined (_OMNIORB) && !defined (_TAO)
Mutex::~Mutex()
{
#ifdef _BOOST
#else
#ifdef _IPC
	sem_close(mutex_);
#else
#ifdef _GNU_PTH
	pthread_mutex_destroy (&mutex_);
#else
#ifdef _SOLARIS
	mutex_destroy (&mutex_);
#else
#ifdef _PURE_WIN32
	CloseHandle (mutex_);
	mutex_ = NULL;
#else
	pthread_mutex_destroy (&mutex_);
#endif
#endif
#endif
#endif
#endif
}
#endif

int Mutex::_lock ()
{
	locked = true;
	int ret = 0;
#ifdef _BOOST
	boost::unique_lock<boost::mutex> lock(mutex_);

	while(count == 0){
		cv.wait(lock);
	}
	count--;
#else
#ifdef _IPC
	sem_wait(mutex_);
#else
#ifdef _GNU_PTH
	ret = pthread_mutex_lock (&mutex_);
#else
#ifdef _SOLARIS
	ret = mutex_lock (&mutex_);
#else
#ifdef _TAO
	ret = acquire();
#else
#ifdef _OMNIORB
	wait ();
#else
#ifdef _PURE_WIN32
	if (WaitForSingleObject (mutex_, INFINITE) != WAIT_OBJECT_0)
		ret = -1;
#else
	ret = pthread_mutex_lock (&mutex_);
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#ifndef _PURE_WIN32
	time = clock ();
#endif

	return ret;
}

int Mutex::_trylock ()
{
	int ret = 0;
#ifdef _BOOST
	if (locked)
		ret = EBUSY;
	else
		ret = _lock ();
#else
#ifdef _IPC
	if (locked)
		ret = EBUSY;
	else
		ret = _lock ();
#else
#ifdef _GNU_PTH
	ret = pthread_mutex_trylock(&mutex_);
#else
#ifdef _SOLARIS
	ret =  mutex_trylock (&mutex_);
#else
#ifdef _TAO
	if(tryacquire() == -1)
		ret = EBUSY;
#else
#ifdef _OMNIORB
	if (trywait () == 0)
		ret = EBUSY;
#else
#ifdef _PURE_WIN32
	if (locked)
		ret = EBUSY;
	else
		ret = _lock ();
#else
	ret = pthread_mutex_trylock (&mutex_);
#endif
#endif
#endif
#endif
#endif
#endif
#endif

	return ret;
}

int Mutex::_unlock ()
{
	int ret = 0;
#ifdef _BOOST
	boost::unique_lock<boost::mutex> lock(mutex_);
    count++;
    cv.notify_one();
#else
#ifdef _IPC
	sem_post(mutex_);
#else
#ifdef _GNU_PTH
	ret = pthread_mutex_unlock (&mutex_);
#else
#ifdef _SOLARIS
	ret = mutex_unlock(&mutex_);
#else
#ifdef _TAO
	ret = release();
#else
#ifdef _OMNIORB
	post ();
#else
#ifdef _PURE_WIN32
	if (!ReleaseSemaphore (mutex_, 1, NULL))
		ret = EPERM;
#else
	ret = pthread_mutex_unlock (&mutex_);
#endif
#endif
#endif
#endif
#endif
#endif
#endif
	locked = false;

	return ret;
}

#ifndef _WIN32
#include <unistd.h>
#include <errno.h>
#include <time.h>

unsigned long GetTickCount()
{
  struct timespec tp;
  unsigned long now; // now in milliseconds.
  if(!clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &tp))
	  now = tp.tv_sec * 1000 + tp.tv_nsec / 1000000;
  return now;
}
#endif


size_t waitForMultipleMutexes (size_t count, Mutex **array, bool bWaitAll, unsigned long  dwMilliseconds)
{
	size_t ret;
#ifdef _PURE_WIN32
	HANDLE *arrayH = new HANDLE[count];
	for (size_t i = 0; i < count; i++)
	{
		arrayH[i] = array[i]->mutex_;
	}
	ret = (size_t) WaitForMultipleObjects (count, arrayH, bWaitAll, dwMilliseconds);
	delete[] arrayH;
#else
	bool finish = false;
	unsigned long begin = 0;
	unsigned long duration = 0;
	size_t i;

	if(dwMilliseconds != INFINITE)
		begin = GetTickCount();

	if(!bWaitAll)
	{
		while(!finish)
		{
			for(i= 0; i < count; i++)
			{
				if(array[i]->_trylock() != EBUSY)
				{
					ret = i + WAIT_OBJECT_0;
					finish = true;
					break;
				}
			}

			if(dwMilliseconds != INFINITE)
			{
				duration = GetTickCount() - begin;
				if (duration >= dwMilliseconds)
					return WAIT_TIMEOUT;
			}

#ifdef _WIN32
			Sleep(1);
#else
			usleep(1);
#endif
		}
	}
	else
	{
		bool first = true;
		bool allLocked = true;

		bool* locked = new bool[count];
		for(i = 0; i < count; i++)
			locked[i] = false;

		while(!finish)
		{
			for(i = 0; i < count; i++)
			{
				if(!locked[i])
				{
					locked[i] = (array[i]->_trylock() != EBUSY);
					if(locked[i] && first)
					{
						ret = i + WAIT_OBJECT_0;
						first = false;
					}
				}
			}
			for(i = 0; i < count; i++)
				allLocked = allLocked && locked[i];
			if(allLocked)
			{
				finish = true;
				delete [] locked;
			}
			else
				allLocked = true;

			if(dwMilliseconds != INFINITE)
			{
				duration = GetTickCount() - begin;
				if (duration >= dwMilliseconds)
				{
					delete [] locked;
					return WAIT_TIMEOUT;
				}
			}

#ifdef _WIN32
			Sleep(1);
#else
			usleep(1);
#endif
		}
	}
#endif  //_PURE_WIN32
	return ret;
}
