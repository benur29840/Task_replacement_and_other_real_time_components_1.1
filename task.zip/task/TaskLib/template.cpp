#ifndef _SYSTEMV

#include "Task.h"
template class ListOfPointers<task>;	//for TheTaskList
template class ListOfPointers<object>;	//for qhead and qtail

#endif //_SYSTEMV
