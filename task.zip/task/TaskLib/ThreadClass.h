/* -*- Mode: C++; -*-
 *                            
 * ThreadClass.h              Created on: 2016/11/09
 *                            Author    : Rock Benoit
 *
 *    Copyright (C) 2016 Rock's Architecture
 *
 * 
 *    The Task library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  
 *    02111-1307, USA
 *
 *
 * Description:
 *
 *
 *      ThreadClass.h
 *
 *    Uses different libraries 
 *    Expressive preprocessor flags to use one of these libraries are :
 *    _BOOST, _GNU_PTH, _SOLARIS, _TAO, _OMNIORB, _PURE_WIN32, default : POSIX pthread
 *
 */

#ifndef _SYSTEMV

#ifdef DEBUG
#pragma message ("#INCLUDING " __FILE__)
#endif

#ifndef _THREADCLASS_H__
#define _THREADCLASS_H__

#include "Mutex.h"

#ifdef _BOOST
#include <boost/thread.hpp>
#endif

#ifdef _TAO
#include <ace/Thread.h>
#endif

#ifdef _TAO
class ThreadClass : public ACE_Thread
#else
#ifdef _OMNIORB
class ThreadClass : public omni_thread
#else
class ThreadClass
#endif
#endif
{
public :
	virtual void Loop() = 0;
#ifdef _BOOST
	friend void run(void*);
#else
#if !defined (_OMNIORB)
	friend unsigned long ThreadFunction (void *lpdwParam);
#if !defined (_PURE_WIN32)
	friend void * threadFunction (void *lpdwParam);
#endif
#else
private :
	void run(void*);
public:
#endif
#endif
public :
	Mutex* buildingMutex;

public:
	ThreadClass();
	~ThreadClass();
#ifdef _BOOST
	boost::thread::id _theTaskId;
#else
#ifdef _GNU_PTH
	pthread_t _theTaskId;
#else
#ifdef _SOLARIS
	thread_t _theTaskId;
#else
#ifdef _TAO
	ACE_thread_t _theTaskId;
#else
#ifdef _OMNIORB
	int _theTaskId;
#else
#ifdef _PURE_WIN32
	DWORD _theTaskId;
	HANDLE objectHandle;
#else
	pthread_t _theTaskId;
#endif
#endif
#endif
#endif
#endif
#endif
};
#endif

#endif //_SYSTEMV
