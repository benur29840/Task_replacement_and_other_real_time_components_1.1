/* -*- Mode: C++; -*-
 *                            
 * ListOfPointers.h                   Created on: 2016/11/09
 *                            Author    : Rock Benoit
 *
 *    Copyright (C) 2016 Rock's Architecture
 *
 * 
 *    The Task library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  
 *    02111-1307, USA
 *
 *
 * Description:
 *
 *
 *      ListOfPointers.h
 *
 *    FIFO\LIFO list of pointers of types, structures or classes
 *    ListOfPointers is a template class
 *
 */


#ifdef DEBUG
#pragma message ("#INCLUDING " __FILE__)
#endif

#ifndef _LISTEP_H
#define _LISTEP_H

#ifdef _WIN32
#include <windows.h>
#endif
#include <cstddef>

#include "Mutex.h"

class ListOfPointersElement;

template <class T>
class ListOfPointers {
	public:

	// Constructors, destructor :

	ListOfPointers();                                       // Constructor of an empty list
	ListOfPointers(std::size_t numberOfT, T *t1, ...);      //Initializing with several *T
	ListOfPointers(const ListOfPointers<T>& x);                     // Constructor by copying
	ListOfPointers(std::size_t sizeMax);                    //Constructor for classes qhead and qtail see Task.h
														//C.f. _lengthMax but not finalized
	~ListOfPointers();                                      // does not destroy T, but T*

	// List's dump and allocation :

	void empty_all (bool destroy = false);          // Empties list, destroying all T* if destroy = true
	ListOfPointers<T>& operator= (const ListOfPointers<T>& x);      // Empties list then allocates the new one
	void concat (ListOfPointers<T> list);                   // Concatenates list at the end

	// List's size :

	std::size_t  length () const;                   // Returns length's list

	// Relation operators :

	bool operator== (const ListOfPointers<T>& x) const;
	bool operator!= (const ListOfPointers<T>& x) const;

	// FIFO's operations

	void put (T *pT);                       // Adds pT at the end of list
	T *unput ();                            // Extracts last list's element and returns it
	void get (T *& rpT);                    // Extracts the first list's element and returns it in rpT
	T *get ();                              // Extracts the first list's element and returns it

	// Array's operations :

	T *operator[] (std::size_t i) const;    // Returns without extracting the i.th element
	T *&  operator[] (std::size_t i);       // Returns without extracting the i.th element for assignment

	// Current element's positioning :

	void first ();                          // Positions on first list's element
	void last ();                           // Positions on last list's element
	void next ();                           // Positions on next list's element
												// (on last element, doesn't move but not_done = false)
	void previous ();                       // Positions on the previous list's element
												// (on the first element, doesn't move but not_done=false)
	std::size_t  seek (std::size_t i);      // Positions current on the i.th element, returns position
												// or -1 if threshold
												// (Positions current on the first or the last if threshold)
	std::size_t  seek (const T *pT);        // Positions the element containing the pT pointeur and returns position
												// or -1 if threshold (on the last one, not_done = true if not found)
	bool  not_done () const;                // Returns threshold's flag not_done

	// Current element's operations :

	std::size_t  read_position () const;            // Returns the current element's position
	void read_current (T *& rpT);                   // Returns, in  rpT, the current element's pointer without extracting it
	T *read_current ();                             // Returns the current element's pointer without extracting it
	void read_next (T *& rpT);                      // Returns, in rpT, the next element without extracting it
	T *read_next ();                                // Returns the next element without extracting it
	void read_previous (T *& rpT);                  // Returns, in  rpT, the previous element's pointer without extracting it
	T *read_previous ();                            // Returns the previous element's pointer without extracting it

	void get_current (T *& rpT);                    // Extracts the current element and returns it in rpT
														// (the current element becomes the next one)
	T *get_current ();                              // Extracts the current element and returns it
														// (the current element becomes the next one)
	void get_next (T *& rpT);                       // Extracts the next element and returns it in rpT
	T *get_next ();                                 // Extracts the next element and returns it
	void get_previous (T *& rpT);                   // Extracts the previous element and returns it in rpT
	T *get_previous ();                             // Extracts the previous element and returns it
	void put_next (T *pT);                          // Puts in an element after current position
	void put_previous (T *pT);                      // Puts in an element before current position


	bool IsFull ();

	#ifdef HAVE_MUTEX
	Mutex *listOperationMutex;                      //see end of this file
	#endif

	private:

	std::size_t _length;
	ListOfPointersElement *_first;
	ListOfPointersElement *_last;
	std::size_t _current_rank;
	ListOfPointersElement *_current;
	bool _not_done;
	std::size_t _lengthMax;
	#ifdef HAVE_MUTEX
	Mutex *protectMutex;
	#endif
};

#endif

//sample of use more specifically for multithtreading :

//ListOfPointers<yourTypeOrClass> List;
//...
//#ifdef HAVE_MUTEX
//List.listOperationMutex->_lock()
//#endif
//for(List.first(); List.not_done(); List.next())
//	...do something on List
//#ifdef HAVE_MUTEX
//List.listOperationMutex->unlock();
//#endif
