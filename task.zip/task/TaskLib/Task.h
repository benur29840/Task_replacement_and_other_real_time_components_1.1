/* -*- Mode: C++; -*-
 *                            
 * Task.h                     Created on: 2016/11/09
 *                            Author    : Rock Benoit
 *
 *    Copyright (C) 2016 Rock's Architecture
 *
 * 
 *    The Task library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  
 *    02111-1307, USA
 *
 *
 * Description:
 *
 *
 *      Task.h
 *
 *    SYSTEM V replacement
 *
 */

#ifdef DEBUG
#pragma message ("#INCLUDING " __FILE__)
#endif

// https://docs.oracle.com/cd/E19205-01/820-4180/man3cc4/task.3.html
#include <iostream>
using namespace std;

#ifdef _SYSTEMV
#include <task.h>
#else

#ifndef _Task_h_
#define _Task_h_

#include "ListOfPointers.h"
#include "ThreadClass.h"

enum qmodetype
{   
	EMODE, // error on empty get or full put
    WMODE, // wait (block) on empty get or full put
    ZMODE  // return 0 on empty get or full put
};

enum statetype
{
    IDLE=1,
    RUNNING=2,
    KILLED=3,
    TERMINATED=4
};

class task;

class object
{
public:

	object();
	~object();

	void alert ();
	static task *this_task ();

	Mutex *objectPendingMutex;

	bool someoneWaitingFor;
};



enum modetype { DEDICATED = 1, SHARED = 2 };

class task : public object, public ThreadClass
{
	virtual void Loop() {};

	public:
	statetype state;

	public:
	#define DEFAULT_MODE DEDICATED
	#define SIZE 3000

	char *t_name;
	int Val;

	public:
	task(char * = 0, modetype = DEFAULT_MODE, int = SIZE);

	~task();

	public:
	void resultis (int);
	int  result();
	void cancel();
	int waitvec (object **);
	statetype rdstate ();
};

class qtail;

class qhead : public object
{
	friend qtail;
	public:
	qhead(qmodetype = WMODE, int = 10000);     // qhead with given mode and max size
	~qhead();

	int    pending ();
	object *get ();
	qtail  *tail ();
	int    rdcount ();

	private:
	qmodetype mode;                 // queue mode
	ListOfPointers<object> *q;              // common queue data
	qtail *theTail;
	Mutex *emptyMutex;
	bool isLocked;

	void    freeHead ();
	void    blockHead ();
};

class qtail : public object
{
	friend qhead;
	public:
	qtail(qmodetype = WMODE, int = 10000);     // qtail with given mode and max size
	qtail(ListOfPointers<object> *queue, qmodetype mod, qhead *qh);
	~qtail();

	int pending ();
	int put (object *);
	qhead *head ();                 // Return the head attached to this tail


	private:
	bool qMustBeDestroyed;
	qmodetype mode;                 // queue mode
	ListOfPointers<object> *q;              // common queue data
	qhead *theHead;
	Mutex *fullMutex;

	void freeTail ();
	void blockTail ();
};

#define thistask (object::this_task ())

task *thistaskBuild ();
/*use
#ifndef _SYSTEMV
		theTask = thistaskBuild ();
#else
		theTask = thistask;
#endif
*/
#endif

#endif //_SYSTEMV
