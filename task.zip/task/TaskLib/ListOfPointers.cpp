/* -*- Mode: C++; -*-
 *                            
 * ListOfPointers.cpp                 Created on: 2016/11/09
 *                            Author    : Rock Benoit
 *
 *    Copyright (C) 2016 Rock's Architecture
 *
 * 
 *    The Task library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  
 *    02111-1307, USA
 *
 *
 * Description:
 *
 *
 *      ListOfPointers.cpp
 *
 *    FIFO\LIFO list of pointers of types, structures or classes
 *    ListOfPointers is a template class
 *
 */

#include "ListOfPointers.h"

#ifdef HAVE_STD
#include <stdarg.h>
#else
#include <varargs.h>
#endif

// -----------------------------------------------------------
// Private class : ListOfPointersElement
// -----------------------------------------------------------

class ListOfPointersElement {
public:

	void *_element;
	ListOfPointersElement *_next;
	ListOfPointersElement *_previous;
	#ifdef HAVE_MUTEX
	Mutex *protectMutex;
	#endif

	ListOfPointersElement(void *elt) : _element (elt), _next (0), _previous (0)
	{
#ifdef HAVE_MUTEX
		protectMutex = new Mutex ();
#endif
	}

	~ListOfPointersElement()
	{
#ifdef HAVE_MUTEX
		delete protectMutex;
		protectMutex = NULL;
#endif
	}

	void insert_next (ListOfPointersElement *pnext)
	{
#ifdef HAVE_MUTEX
		protectMutex->_lock ();
#endif
		if (_next)
			_next->_previous = pnext;
		pnext->_previous = this;
		pnext->_next = _next;
		_next = pnext;
#ifdef HAVE_MUTEX
		protectMutex->_unlock ();
#endif
	}

	void insert_previous (ListOfPointersElement *pprevious)
	{
#ifdef HAVE_MUTEX
		protectMutex->_lock ();
#endif
		if (_previous)
			_previous->_next = pprevious;
		pprevious->_next = this;
		pprevious->_previous = _previous;
		_previous = pprevious;
#ifdef HAVE_MUTEX
		protectMutex->_unlock ();
#endif
	}

	void extract ()
	{
#ifdef HAVE_MUTEX
		protectMutex->_lock ();
#endif
		if (_next)
			_next->_previous = _previous;
		if (_previous)
			_previous->_next = _next;
#ifdef HAVE_MUTEX
		protectMutex->_unlock ();
#endif
	}

	private:

	ListOfPointersElement()
	{
	}

};




// -----------------------------------------------------------
// ListOfPointers class's implementation
// -----------------------------------------------------------

template <class T>
ListOfPointers<T>::ListOfPointers()
{
	_length = _current_rank = 0;
	_first = _last = _current = 0;
	_not_done = false;
#ifdef HAVE_MUTEX
	protectMutex = new Mutex ();
	listOperationMutex = new Mutex ();
#endif
}

template <class T>
ListOfPointers<T>::ListOfPointers(std::size_t nbOfT, T *t1, ...)
{
	_length = _current_rank = 0;
	_first = _last = _current = NULL;
	_not_done = true;
#ifdef HAVE_MUTEX
	protectMutex = new Mutex ();
	listOperationMutex = new Mutex ();
#endif

	va_list lste;

#ifndef __GNUC__
	va_start (lste, nbOfT);
#else
	va_start (lste, t1);
#endif

	for (std::size_t i = 0; i < nbOfT; i++)
	{
		put ((T *) va_arg (lste, T *));
	}

	va_end (lste);

	first ();
}

template <class T>
ListOfPointers<T>::ListOfPointers(const ListOfPointers<T>& x)
{
	_length = _current_rank = 0;
	_first = _last = _current = 0;
	_not_done = false;

#ifdef HAVE_MUTEX
	protectMutex = new Mutex ();
	listOperationMutex = new Mutex ();
#endif

	ListOfPointersElement *pcopy = x._first;
	while (pcopy)
	{
		put ((T *) (pcopy->_element));
		pcopy = pcopy->_next;
	}
	seek (x._current_rank);
}

template <class T>
ListOfPointers<T>::~ListOfPointers()
{
	empty_all ();

#ifdef HAVE_MUTEX
	delete listOperationMutex;
	listOperationMutex = NULL;
	delete protectMutex;
	protectMutex = NULL;
#endif
}

template <class T>
void ListOfPointers<T>::empty_all (bool destroy)
{
	while (_first)
	{
		if (destroy)
			delete(get ());
		else
			get ();
	}
}

template <class T>
void ListOfPointers<T>::concat (ListOfPointers<T> liste)
{
	for (liste.first (); liste.not_done (); liste.next ())
	{
		put (liste.read_current ());
	}
}

template <class T>
ListOfPointers<T>& ListOfPointers<T>::operator= (const ListOfPointers<T>& x)
{
	if (this != &x)
	{
		empty_all ();
		ListOfPointersElement *pcopy = x._first;
		while (pcopy)
		{
			put ((T *) (pcopy->_element));
			pcopy = pcopy->_next;
		}
		seek (x._current_rank);
#ifdef HAVE_MUTEX
		protectMutex = new Mutex ();
		listOperationMutex = new Mutex ();
#endif
	}
	return *this;
}

template <class T>
std::size_t ListOfPointers<T>::length () const
{
	return _length;
}

template <class T>
bool ListOfPointers<T>::operator== (const ListOfPointers<T>& x) const
{
#ifdef HAVE_MUTEX
	protectMutex->_lock ();
#endif
	if (_length != x._length)
	{
#ifdef HAVE_MUTEX
		protectMutex->_unlock ();
#endif
		return false;
	}
	ListOfPointersElement *cour = _first, *courx = x._first;
	while (cour)
	{
		if (cour->_element != courx->_element)
		{
#ifdef HAVE_MUTEX
			protectMutex->_unlock ();
#endif
			return false;
		}
		cour = cour->_next;
		courx = courx->_next;
	}
#ifdef HAVE_MUTEX
	protectMutex->_unlock ();
#endif
	return true;
}

template <class T>
bool ListOfPointers<T>::operator!= (const ListOfPointers<T>& x) const
{
	return !operator== (x);
}

template <class T>
void ListOfPointers<T>::put (T *pT)
{
#ifdef HAVE_MUTEX
	protectMutex->_lock ();
#endif
	ListOfPointersElement *elt = new ListOfPointersElement ((void *) pT);
	if (_last)
	{
		_last->insert_next (elt);
		_last = elt;
	}
	else
	{
		_first = _last = _current = elt;
	}
	_length++; _not_done = true;
#ifdef HAVE_MUTEX
	protectMutex->_unlock ();
#endif
}

template <class T>
T *ListOfPointers<T>::unput ()
{
	last ();
	return get_current ();
}

template <class T>
void ListOfPointers<T>::get (T *& rpT)
{
	rpT = get ();
}

template <class T>
T *ListOfPointers<T>::get ()
{
	T *ret = 0;

#ifdef HAVE_MUTEX
	protectMutex->_lock ();
#endif
	if (_first)
	{
		ret = (T *) (_first->_element);
		ListOfPointersElement *tmp = _first;
		_first = _first->_next;
		tmp->extract ();
		delete tmp;
		if (!_first)
		{
			_last = 0;
			_not_done = false;
		}
		_length--;
		if (_current_rank)
			_current_rank--;
		else
			_current = _first;
	}
#ifdef HAVE_MUTEX
	protectMutex->_unlock ();
#endif
	return ret;
}

template <class T>
T *ListOfPointers<T>::operator[] (std::size_t i) const
{
	ListOfPointersElement *pcpt = 0;

	std::size_t cpt;
#ifdef HAVE_MUTEX
	protectMutex->_lock ();
#endif
	if (i < _length)
	{
		for (cpt = 0, pcpt = _first; cpt < i; cpt++, pcpt = pcpt->_next)
		{
		}
#ifdef HAVE_MUTEX
		protectMutex->_unlock ();
#endif
		return (T *) (pcpt->_element);
	}
#ifdef HAVE_MUTEX
	protectMutex->_unlock ();
#endif
	return (T *) 0;
}

template <class T>
T *& ListOfPointers<T>::operator[] (std::size_t i)
{
	seek (i);
	return (T *&) *(&(_current->_element));
}

template <class T>
void ListOfPointers<T>::first ()
{
#ifdef HAVE_MUTEX
	protectMutex->_lock ();
#endif
	_current = _first;
	_current_rank = 0;
	if (!_current)
		_not_done = false;
	else
		_not_done = true;
#ifdef HAVE_MUTEX
	protectMutex->_unlock ();
#endif
}

template <class T>
void ListOfPointers<T>::last ()
{
#ifdef HAVE_MUTEX
	protectMutex->_lock ();
#endif
	_current = _last;
	_current_rank = (_length < 1 ? 0 : _length - 1);
	if (!_current)
		_not_done = false;
	else
		_not_done = true;
#ifdef HAVE_MUTEX
	protectMutex->_unlock ();
#endif
}

template <class T>
void ListOfPointers<T>::next ()
{
#ifdef HAVE_MUTEX
	protectMutex->_lock ();
#endif
	_not_done = true;
	if (_current)
	{
		_current = _current->_next;
		_current_rank++;
	}
	if (!_current)
	{
		_current = _last;
		_current_rank = (_length < 1 ? 0 : _length - 1);
		_not_done = false;
	}
#ifdef HAVE_MUTEX
	protectMutex->_unlock ();
#endif
}

template <class T>
void ListOfPointers<T>::previous ()
{
#ifdef HAVE_MUTEX
	protectMutex->_lock ();
#endif
	_not_done = true;
	if (_current)
	{
		_current = _current->_previous;
		_current_rank--;
	}
	if (!_current)
	{
		_current = _first;
		_current_rank = 0;
		_not_done = false;
	}
#ifdef HAVE_MUTEX
	protectMutex->_unlock ();
#endif
}

template <class T>
std::size_t ListOfPointers<T>::seek (std::size_t i)
{
#ifdef HAVE_MUTEX
	protectMutex->_lock ();
#endif
	if (i >= _length)
	{
		_current = _last;
		_current_rank = (_length - 1 < 0 ? 0 : _length - 1);
		_not_done = false;
#ifdef HAVE_MUTEX
		protectMutex->_unlock ();
#endif
		return -1;
	}
	else
	{
		for (_current_rank = 0, _current = _first; _current_rank < i; _current_rank++, _current = _current->_next)
		{
		}
		_not_done = true;
	}
#ifdef HAVE_MUTEX
	protectMutex->_unlock ();
#endif
	return i;
}

template <class T>
std::size_t ListOfPointers<T>::seek (const T *pT)
{
#ifdef HAVE_MUTEX
	protectMutex->_lock ();
#endif
	_not_done = true;
	for (_current_rank = 0, _current = _first; _current; _current_rank++, _current = _current->_next)
	{
		if (_current->_element == (void *) pT)
			break;
	}
#ifdef HAVE_MUTEX
	protectMutex->_unlock ();
#endif
	if (!_current)
	{
		_current = _last;
		_current_rank = (_length < 1 ? 0 : _length - 1);
		_not_done = false;
		return -1;
	}
	return _current_rank;
}

template <class T>
bool ListOfPointers<T>::not_done () const
{
	return _not_done;
}

template <class T>
std::size_t ListOfPointers<T>::read_position () const
{
	return _current_rank;
}

template <class T>
void ListOfPointers<T>::read_current (T *& rpT)
{
	rpT = read_current ();
}

template <class T>
T *ListOfPointers<T>::read_current ()
{
#ifdef HAVE_MUTEX
	protectMutex->_lock ();
#endif
	T *ret = 0;
	if (_current)
		ret = (T *) (_current->_element);
#ifdef HAVE_MUTEX
	protectMutex->_unlock ();
#endif
	return ret;
}

template <class T>
void ListOfPointers<T>::read_next (T *& rpT)
{
	rpT = read_next ();
}

template <class T>
T *ListOfPointers<T>::read_next ()
{
	next ();
	T *ret = read_current ();
	previous ();
	return ret;
}

template <class T>
void ListOfPointers<T>::read_previous (T *& rpT)
{
	rpT = read_previous ();
}

template <class T>
T *ListOfPointers<T>::read_previous ()
{
	previous ();
	T *ret = read_current ();
	next ();
	return ret;
}

template <class T>
void ListOfPointers<T>::get_current (T *& rpT)
{
	rpT = get_current ();
}

template <class T>
T *ListOfPointers<T>::get_current ()
{
	T *ret = 0;

#ifdef HAVE_MUTEX
	protectMutex->_lock ();
#endif
	if (_current)
	{
		ListOfPointersElement *tmp = _current;
		ret = (T *) (_current->_element);
		_current->extract ();
		if (_current == _first)
			_first = _current->_next;
		if (_current == _last)
			_last = _current->_previous;
		_length--;
		_current = _current->_next;
		if (!_current)
		{
			_current = _last;
			_current_rank = (_length < 1 ? 0 : _length - 1);
			_not_done = false;
		}
		delete tmp;
#ifdef HAVE_MUTEX
		tmp = NULL;
#endif
	}
	if (!_current)
		_not_done = false;
#ifdef HAVE_MUTEX
	protectMutex->_unlock ();
#endif
	return ret;
}

template <class T>
void ListOfPointers<T>::get_next (T *& rpT)
{
	rpT = get_next ();
}

template <class T>
T *ListOfPointers<T>::get_next ()
{
	T *ret = 0;

	next ();
	if (_not_done)
	{
		ret = get_current ();
		if (_not_done)
			previous ();
		else
			_not_done = true;
	}
	return ret;
}

template <class T>
void ListOfPointers<T>::get_previous (T *& rpT)
{
	rpT = get_previous ();
}

template <class T>
T *ListOfPointers<T>::get_previous ()
{
	T *ret = 0;

	previous ();
	if (_not_done)
		ret = get_current ();
	return ret;
}

template <class T>
void ListOfPointers<T>::put_next (T *pT)
{
	ListOfPointersElement *tmp = new ListOfPointersElement (pT);

#ifdef HAVE_MUTEX
	protectMutex->_lock ();
#endif
	if (_current)
	{
		_current->insert_next (tmp);
		if (_current == _last)
			_last = tmp;
	}
	else
	{
		_first = _last = _current = tmp;
	}
	_not_done = true;
	_length++;
#ifdef HAVE_MUTEX
	protectMutex->_unlock ();
#endif
}

template <class T>
void ListOfPointers<T>::put_previous (T *pT)
{
	ListOfPointersElement *tmp = new ListOfPointersElement (pT);

#ifdef HAVE_MUTEX
	protectMutex->_lock ();
#endif
	if (_current)
	{
		_current->insert_previous (tmp);
		if (_current == _first)
			_first = tmp;
		_current_rank++;
	}
	else
	{
		_first = _last = _current = tmp;
	}
	_not_done = true;
	_length++;
#ifdef HAVE_MUTEX
	protectMutex->_unlock ();
#endif
}


template <class T>
ListOfPointers<T>::ListOfPointers(std::size_t sizeMax)
{
	_lengthMax = sizeMax;
	_length = _current_rank = 0;
	_first = _last = _current = 0;
	_not_done = false;
#ifdef HAVE_MUTEX
	protectMutex = new Mutex ();
#endif
}

template <class T>
bool ListOfPointers<T>::IsFull ()
{
	if (length () == _lengthMax)
		return true;
	else
		return false;
}

#include "template.cpp"
