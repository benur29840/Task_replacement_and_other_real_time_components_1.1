/* -*- Mode: C++; -*-
 *                            
 * Tasklist.cpp               Created on: 2016/11/09
 *                            Author    : Rock Benoit
 *
 *    Copyright (C) 2016 Rock's Architecture
 *
 * 
 *    The Task library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  
 *    02111-1307, USA
 *
 *
 * Description:
 *
 *
 *      Tasklist.cpp
 *
 *
 */

#ifndef _SYSTEMV

#include "TaskList.h"

TaskList::TaskList()
{
	length = 0;
}

TaskList::~TaskList()
{
	TaskPtrList.empty_all(false);
	length = 0;
}

void TaskList::Add(task* theTask)
{
	TaskPtrList.listOperationMutex->_lock();
	TaskPtrList.put(theTask);
	length ++;
	TaskPtrList.listOperationMutex->_unlock();
}

void TaskList::Remove(task* theTask)
{
	TaskPtrList.listOperationMutex->_lock();

	if(TaskPtrList.length() > 0)
		for (TaskPtrList.first(); TaskPtrList.not_done(); TaskPtrList.next())
		{
			if(TaskPtrList.read_current() == theTask)
			{
				TaskPtrList.get_current();
				length --;
				break;
			}
		}

	TaskPtrList.listOperationMutex->_unlock();
}

#ifdef _BOOST
	task* TaskList::Find(boost::thread::id* taskId)
#else
#ifdef _GNU_PTH
	task* TaskList::Find(pthread_t* taskId)
#else
#ifdef _SOLARIS
	task* TaskList::Find(thread_t* taskId)
#else
#ifdef _TAO
	task* TaskList::Find(ACE_thread_t* taskId)
#else
#ifdef _OMNIORB
	task* TaskList::Find(int* taskId)
#else
#ifdef _PURE_WIN32
	task*	TaskList::Find(DWORD* taskId)
#else
	task* TaskList::Find(pthread_t* taskId)
#endif
#endif
#endif
#endif
#endif
#endif
{
	task* ret;

	TaskPtrList.listOperationMutex->_lock();

	TaskPtrList.first();
#if defined  (_PURE_WIN32) || defined (_OMNIORB) || defined (_TAO) || defined (_SOLARIS) || defined (_BOOST)
	while(TaskPtrList.length() != 0 && TaskPtrList.read_current()->_theTaskId != *taskId )
#else // pthread or _GNU_PTH
	while(TaskPtrList.length() != 0 && !pthread_equal(TaskPtrList.read_current()->_theTaskId, *taskId ))
#endif
	{
		TaskPtrList.next();
	}
	
	if(TaskPtrList.length() == 0)
		ret = NULL;
	else
		ret = TaskPtrList.read_current();

	TaskPtrList.listOperationMutex->_unlock();

	return ret;
}

bool TaskList::AreOthersTasksTerminated(ThreadClass* taskHandle)
{
	bool ret = true;

	TaskPtrList.listOperationMutex->_lock();

	task* aTask = NULL;

	if(length > 0)
	{
		TaskPtrList.first();

		for(int i = 0; i < length; i++)
		{
			aTask = TaskPtrList.read_current();
			if(aTask != NULL)
			{
				if((ThreadClass*)aTask != taskHandle)
				{
					if(aTask->rdstate() != TERMINATED)
					{
						ret = false;
						TaskPtrList.next();
					}
					else
					{
						//pull out the list
						TaskPtrList.get_current();
						length --;
//						delete aTask;//do not run correctly ????? will be deleted when "QUIT"
					}
				}
				else
					TaskPtrList.next();
			}
			else
			{
				//pull out the list
				TaskPtrList.get_current();
				length --;
			}
		}
	}
	
	TaskPtrList.listOperationMutex->_unlock();

	return ret;
}



task* TaskList::last()
{
	task* ret = NULL;

	TaskPtrList.listOperationMutex->_lock();

	if(TaskPtrList.length() != 0)
	{
		TaskPtrList.last();
		ret = TaskPtrList.read_current();
	}

	TaskPtrList.listOperationMutex->_unlock();

	return ret;
}

#endif //_SYSTEMV
